
public class Address {
	City city;
	String steert;
	public City getCity() {
		return city;
	}
	public void setCity(City city) {
		this.city = city;
	}
	public String getSteert() {
		return steert;
	}
	public void setSteert(String steert) {
		this.steert = steert;
	}

	

	
}
