
public class Bank {
String name;
String bankAccount;
String bankCode;
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getBankAccount() {
	return bankAccount;
}
public void setBankAccount(String bankAccount) {
	this.bankAccount = bankAccount;
}
public String getBankCode() {
	return bankCode;
}
public void setBankCode(String bankCode) {
	this.bankCode = bankCode;
}

}
